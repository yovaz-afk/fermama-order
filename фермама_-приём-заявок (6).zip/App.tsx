
import React, { useState, useMemo, useCallback } from 'react';
import { Plus, Trash2, Send, AlertCircle, CheckCircle2, ChevronDown, User, Store, Calendar, Copy, RotateCcw, MessageSquare, Share2 } from 'lucide-react';
import { MANAGERS, PRODUCTS } from './constants';
import { OrderItem } from './types';

// Вспомогательные функции для сортировки
const getBaseName = (name: string) => name.replace(/\s*(?:(?:\d+\s*(?:гр|г|г))|вес\.)\s*$/i, '').trim();
const getWeightInGram = (name: string) => {
  const match = name.match(/(\d+)\s*(?:гр|г|г)/i);
  return match ? parseInt(match[1]) : Infinity;
};

const SORTED_PRODUCTS = [...PRODUCTS].sort((a, b) => {
  const baseA = getBaseName(a.name);
  const baseB = getBaseName(b.name);
  if (baseA !== baseB) return baseA.localeCompare(baseB, 'ru');
  if (a.unit === 'шт' && b.unit === 'кг') return -1;
  if (a.unit === 'кг' && b.unit === 'шт') return 1;
  if (a.unit === 'шт' && b.unit === 'шт') return getWeightInGram(a.name) - getWeightInGram(b.name);
  return 0;
});

// Компонент строки
const Row = React.memo(({ 
  item, 
  onRemove, 
  onUpdate 
}: { 
  item: OrderItem; 
  onRemove: (id: string) => void; 
  onUpdate: (id: string, updates: Partial<OrderItem>) => void;
}) => {
  const product = PRODUCTS.find(p => p.id === item.productId);
  const sum = product ? item.quantity * product.price : 0;

  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let valStr = e.target.value.replace(',', '.');
    // Разрешаем только цифры и одну точку
    if (valStr !== '' && !/^\d*\.?\d*$/.test(valStr)) return;
    
    const val = parseFloat(valStr) || 0;
    onUpdate(item.id, { quantity: product?.unit === 'шт' ? Math.floor(val) : val });
  };

  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col gap-3">
      <div className="flex justify-between items-start gap-2">
        <div className="flex-1">
          <label className="text-[11px] text-slate-900 font-black uppercase mb-1 block tracking-wider">Товар</label>
          <div className="relative">
            <select
              value={item.productId}
              onChange={(e) => {
                const selectedProduct = PRODUCTS.find(p => p.id === e.target.value);
                onUpdate(item.id, { 
                  productId: e.target.value, 
                  quantity: selectedProduct?.unit === 'кг' ? 1.0 : 1 
                });
              }}
              className={`w-full text-sm font-bold border-none focus:ring-0 p-0 bg-transparent cursor-pointer appearance-none ${!item.productId ? 'text-slate-400' : 'text-slate-900'}`}
            >
              <option value="" disabled hidden>Нажмите, чтобы выбрать...</option>
              {SORTED_PRODUCTS.map(p => (
                <option key={p.id} value={p.id} className="text-slate-900">{p.name}</option>
              ))}
            </select>
          </div>
        </div>
        <button 
          onClick={() => onRemove(item.id)}
          className="text-slate-300 hover:text-red-500 p-1 transition-colors"
        >
          <Trash2 size={18} />
        </button>
      </div>

      <div className="grid grid-cols-3 gap-4 border-t border-slate-100 pt-3">
        <div>
          <label className="text-[10px] text-slate-900 font-black uppercase mb-1 block">Цена</label>
          <div className="text-sm font-bold text-slate-600">
            {product ? `${product.price}₽ / ${product.unit}` : '—'}
          </div>
        </div>
        <div>
          <label className="text-[10px] text-slate-900 font-black uppercase mb-1 block">Количество</label>
          <input
            type="text"
            inputMode="decimal"
            disabled={!item.productId}
            value={item.quantity === 0 ? '' : item.quantity}
            onChange={handleQuantityChange}
            placeholder="0"
            className="w-full text-sm font-black bg-slate-50 disabled:bg-slate-100 disabled:opacity-50 rounded-lg px-2 py-1.5 border border-slate-200 focus:outline-none focus:border-green-600"
          />
        </div>
        <div className="text-right">
          <label className="text-[10px] text-slate-900 font-black uppercase mb-1 block">Сумма</label>
          <div className="text-sm font-black text-green-700">
            {sum.toLocaleString('ru-RU')} ₽
          </div>
        </div>
      </div>
    </div>
  );
});

const App: React.FC = () => {
  const [selectedManager, setSelectedManager] = useState<string>(MANAGERS[0].name);
  const [clientName, setClientName] = useState<string>('');
  const [orderDate, setOrderDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [orderComment, setOrderComment] = useState<string>('');
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [status, setStatus] = useState<{ type: 'success' | 'error', msg: string } | null>(null);

  const addRow = useCallback(() => {
    setOrderItems(prev => [
      ...prev,
      { id: Math.random().toString(36).substr(2, 9), productId: '', quantity: 0 }
    ]);
  }, []);

  const removeRow = useCallback((id: string) => {
    setOrderItems(prev => prev.filter(item => item.id !== id));
  }, []);

  const updateItem = useCallback((id: string, updates: Partial<OrderItem>) => {
    setOrderItems(prev => prev.map(item => item.id === id ? { ...item, ...updates } : item));
  }, []);

  const totalSum = useMemo(() => {
    return orderItems.reduce((acc, item) => {
      const product = PRODUCTS.find(p => p.id === item.productId);
      return product ? acc + (item.quantity * product.price) : acc;
    }, 0);
  }, [orderItems]);

  const generateMessageText = () => {
    const dateFormatted = new Date(orderDate).toLocaleDateString('ru-RU');
    let text = `Заявка ФерМама\n\n`;
    text += `Менеджер: ${selectedManager}\n`;
    text += `Клиент: ${clientName || 'Не указан'}\n`;
    text += `Дата: ${dateFormatted}\n\n`;
    
    const validItems = orderItems.filter(item => item.productId !== '');
    if (validItems.length > 0) {
      text += `Список позиций:\n`;
      validItems.forEach((item, index) => {
        const product = PRODUCTS.find(p => p.id === item.productId);
        if (product) {
          const sum = item.quantity * product.price;
          text += `${index + 1}) ${product.name} — ${item.quantity} ${product.unit} × ${product.price} ₽ = ${sum.toLocaleString('ru-RU')} ₽\n`;
        }
      });
    }

    if (orderComment.trim()) {
      text += `\nКомментарий: ${orderComment.trim()}\n`;
    }

    text += `\nИТОГОВАЯ СУММА: ${totalSum.toLocaleString('ru-RU')} ₽`;
    return text;
  };

  const handleCopy = async () => {
    if (orderItems.length === 0) return;
    const text = generateMessageText();
    try {
      await navigator.clipboard.writeText(text);
      setStatus({ type: 'success', msg: 'Текст скопирован' });
      setTimeout(() => setStatus(null), 3000);
    } catch (err) {
      setStatus({ type: 'error', msg: 'Не удалось скопировать' });
    }
  };

  const handleSend = async () => {
    if (orderItems.length === 0 || orderItems.every(i => !i.productId)) {
      setStatus({ type: 'error', msg: 'Добавьте товары в заявку' });
      return;
    }
    const text = generateMessageText();
    
    // Пытаемся использовать нативный шеринг (позволяет выбрать любой мессенджер)
    if (navigator.share) {
      try {
        await navigator.share({
          text: text
        });
      } catch (err) {
        // Если отмена или ошибка, пробуем Telegram напрямую
        const encodedText = encodeURIComponent(text);
        window.open(`https://t.me/share/url?url=&text=${encodedText}`, '_blank');
      }
    } else {
      // Фолбэк на Telegram Share Link
      const encodedText = encodeURIComponent(text);
      window.open(`https://t.me/share/url?url=&text=${encodedText}`, '_blank');
    }
  };

  const handleReset = () => {
    if (window.confirm('Очистить форму заявки?')) {
      setOrderItems([]);
      setOrderComment('');
      setClientName('');
      setStatus(null);
    }
  };

  return (
    <div className="min-h-screen max-w-lg mx-auto pb-48 bg-slate-50/50">
      <header className="bg-white sticky top-0 z-20 px-4 py-4 border-b border-slate-100 flex justify-between items-center shadow-sm">
        <div className="flex items-center gap-2">
          <img src="https://raw.githubusercontent.com/yovaz-afk/fermama-order/main/logo.jpg" alt="Лого" className="w-8 h-8 rounded-full object-cover border border-slate-100" onError={(e) => (e.currentTarget.src = "https://placehold.co/100x100?text=Ф")} />
          <h1 className="font-bold text-slate-900 tracking-tight text-lg underline decoration-green-500 decoration-2 underline-offset-4">Заявки ФерМама</h1>
        </div>
        {(orderItems.length > 0 || clientName || orderComment) && (
          <button onClick={handleReset} className="flex items-center gap-1 text-xs font-bold text-red-500 bg-red-50 px-3 py-1.5 rounded-full transition-colors">
            <RotateCcw size={14} /> Очистить
          </button>
        )}
      </header>

      <main className="px-4 py-6 space-y-6">
        {status && (
          <div className={`flex items-center gap-3 p-4 rounded-xl border animate-in fade-in slide-in-from-top-2 duration-300 ${
            status.type === 'success' ? 'bg-green-50 border-green-100 text-green-800' : 'bg-red-50 border-red-100 text-red-800'
          }`}>
            {status.type === 'success' ? <CheckCircle2 size={18} /> : <AlertCircle size={18} />}
            <span className="text-sm font-bold">{status.msg}</span>
          </div>
        )}

        <section className="bg-white p-5 rounded-3xl shadow-sm border border-slate-100 space-y-5">
          <div className="space-y-1.5">
            <label className="text-[12px] text-slate-900 font-black uppercase flex items-center gap-1.5 tracking-wider">
              <User size={14} className="text-green-600" /> Менеджер
            </label>
            <div className="relative">
              <select
                value={selectedManager}
                onChange={e => setSelectedManager(e.target.value)}
                className="w-full appearance-none bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3.5 text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all cursor-pointer"
              >
                {MANAGERS.map(m => (
                  <option key={m.name} value={m.name}>{m.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-4 top-4 text-slate-400 pointer-events-none" size={18} />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] text-slate-900 font-black uppercase flex items-center gap-1.5 tracking-wider">
              <Store size={14} className="text-green-600" /> Клиент
            </label>
            {/* Используем textarea для стабильного ввода без сброса фокуса */}
            <textarea
              rows={1}
              placeholder="Введите название магазина"
              value={clientName}
              onChange={e => setClientName(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3.5 text-sm font-black text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all resize-none overflow-hidden"
              style={{ height: '50px' }}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-[12px] text-slate-900 font-black uppercase flex items-center gap-1.5 tracking-wider">
              <Calendar size={14} className="text-green-600" /> Дата приёма
            </label>
            <input
              type="date"
              value={orderDate}
              onChange={e => setOrderDate(e.target.value)}
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3.5 text-sm font-black text-slate-900 focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all"
            />
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-black text-slate-900 text-[13px] tracking-tight uppercase">Состав заявки</h3>
            <span className="text-[10px] bg-slate-900 text-white px-2.5 py-1 rounded-full font-black">
              {orderItems.filter(i => i.productId).length} ПОЗ.
            </span>
          </div>

          <div className="space-y-4">
            {orderItems.map(item => (
              <Row key={item.id} item={item} onRemove={removeRow} onUpdate={updateItem} />
            ))}
          </div>

          <button
            onClick={addRow}
            className="w-full flex items-center justify-center gap-2 py-6 bg-white border-2 border-dashed border-slate-300 rounded-2xl text-slate-900 font-black text-sm hover:border-green-500 hover:text-green-700 transition-all active:scale-[0.98] shadow-sm"
          >
            <Plus size={20} /> ДОБАВИТЬ ТОВАР
          </button>
        </section>

        <section className="space-y-1.5">
          <label className="text-[12px] text-slate-900 font-black uppercase flex items-center gap-1.5 tracking-wider px-1">
            <MessageSquare size={14} className="text-green-600" /> Комментарий
          </label>
          <textarea
            placeholder="Ваши примечания к этому заказу..."
            value={orderComment}
            onChange={e => setOrderComment(e.target.value)}
            className="w-full min-h-[110px] bg-white border border-slate-200 rounded-3xl px-4 py-4 text-sm font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all shadow-sm resize-none"
          />
        </section>
      </main>

      <footer className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-white/95 backdrop-blur-md border-t border-slate-200 p-5 shadow-[0_-10px_40px_rgba(0,0,0,0.08)] z-20 rounded-t-[2.5rem]">
        <div className="flex items-center justify-between mb-5 px-1">
          <span className="text-slate-900 font-black uppercase text-[11px] tracking-widest">Итого к оплате</span>
          <span className="text-2xl font-black text-slate-900">
            {totalSum.toLocaleString('ru-RU')} <span className="text-lg font-bold text-green-600">₽</span>
          </span>
        </div>
        
        <div className="flex gap-3">
          <button
            onClick={handleCopy}
            className="flex-1 h-15 rounded-2xl flex items-center justify-center gap-2 bg-slate-100 text-slate-900 font-black hover:bg-slate-200 transition-all active:scale-95"
            title="Скопировать"
          >
            <Copy size={22} />
          </button>
          <button
            onClick={handleSend}
            className="flex-[3] h-15 rounded-2xl flex items-center justify-center gap-3 text-white font-black text-lg bg-[#24A1DE] hover:bg-[#1e8dbf] shadow-xl shadow-blue-100 transition-all active:scale-95"
          >
            ОТПРАВИТЬ <Share2 size={22} />
          </button>
        </div>
      </footer>
    </div>
  );
};

export default App;
