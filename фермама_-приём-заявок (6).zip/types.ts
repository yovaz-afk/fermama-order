
export type Unit = 'шт' | 'кг';

export interface Product {
  id: string;
  name: string;
  unit: Unit;
  price: number;
}

export interface OrderItem {
  id: string;
  productId: string;
  quantity: number;
}

export interface Manager {
  name: string;
  clients: string[];
}
